clear all;
clc;
% 1) Determine a ordem das seguintes matrizes:
X = [ 5 0 0 0 0 1];
disp( [ 'Ordem de X � ' num2str( length(X) ) ] )
Y = [ 2; 4; 6; 10];
disp( [ 'Ordem de Y � ' num2str( length(Y) ) ] )
Z = [ 5 3 5; 6 2 -3];
disp( [ 'Ordem de Z � ' num2str( length(Z) ) ] )
K = [ 3 4 5 7 9 10 ];
disp( [ 'Ordem de K � ' num2str( length(K) ) ] )
P = [X ; K ; X];
disp( [ 'Ordem de P � ' num2str( length(P) ) ] )

% 2) Determine a transposta de P.
disp(' Transposta de P:')
P.'

% 3) Crie uma matriz Q quadrada de ordem 5 onde os elementos s�o todos iguais a um.
Q = ones(5)

% 4) Crie uma matriz W quadrada de ordem 5 com elementos rand�micos. (Dica: comando rand)
W = rand(5)

% 5) Determine a inversa de W.
disp('Inversa de W')
inv( W )

%6) Determine W 4 .
W^4
%7) Determine Z = W 4. W -1
Z = W^4.*inv(W)

%8) Liste somente a primeira linha de Z.
disp('Primeira linha de Z')
Z(1,:)

%9) Liste a �ltima coluna de Z.
disp('Primeira coluna de Z')
Z(:,1)

%10) Substitua todos os elementos da �ltima coluna por 3 para a matriz Z.
disp('Z com �ltima coluna substituida por 3 ')
Z(:,end) = 3

%11) Qual o maior e menor elemento da matriz Z. (Dica: comandos max e min)
disp( ['Menor elemento de Z = ' num2str( min( min(Z, [], 1 ) ) ) ] )
disp( ['Maior elemento de Z = ' num2str( max( max(Z, [], 1 ) ) ) ] )

%12) Qual a raz�o entre o maior e menor elemento de Z.
disp([ ' Raz�o entre o menor e o maior valor: ' num2str(min( min(Z, [], 1 ) ) / max( max(Z, [], 1 ) ) ) ] )

