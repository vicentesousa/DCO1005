% construir casas
clc;
clear all;
disp('Software para constru�ao de casa (hipot�tico)')
disp('')
disp(' Exerc�cio do mini-curso de Matlab - 2010.2')
disp('')

material = [5 20 16 7 17; ...
            7 18 12 9 21;...
            6 25 8 5 13];

quantcasas(1) = input('Digite a quantidade de casas do estilo Moderno voc� deseja construir: ');
quantcasas(2) = input('Digite a quantidade de casas do estilo Mediterr�neo voc� deseja construir: ');
quantcasas(3) = input('Digite a quantidade de casas do estilo Colonial voc� deseja construir: ');

preco = [15 8 5 1 10];
clc;
disp('----------------------')
disp([' Projeto das seguintes casas: ']);
disp(['    Estilo Moderno = ' num2str(quantcasas(1))']);
disp(['    Estilo Mediterr�neo = ' num2str(quantcasas(2))]);
disp(['    Estilo Colonial = ' num2str(quantcasas(3))]);
disp('----------------------')

disp('Detalhamento do Material para todas as casas');
materialtotal = quantcasas*material;
disp([' Ferro = ' num2str(materialtotal(1))]);
disp([' Madeira = ' num2str(materialtotal(2))]);
disp([' Vidro = ' num2str(materialtotal(3))]);
disp([' Tinta = ' num2str(materialtotal(4))]);
disp([' Tijolo = ' num2str(materialtotal(5))]);
disp(' ')
disp([' Pre�o total do projeto = R$ ' num2str(materialtotal*preco')])
disp(' ')
precomaterial = preco*material';
disp([' Pre�o de cada casa (MODERNO, MEDITERR�NEO E COLONIAL) = R$ ' num2str(precomaterial)])


    

disp('----------------------')