clc;
clear all;
% Crie uma express�o que calcule o valor de y para as equa��es abaixo. 
% Definia x variando de 2 a 19 espa�ados de 5 em 5 unidades. 
x = 2:5:19;

% item a
y = x.^2;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item b
y = (x-1).^3;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item c
y = (x.^2-1).^3;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item d
y = log10(3*x)/2 + x.^2;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item e
y = log(3*x)/2 + x.^2;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item f
y = exp(4*x);
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item g
y = sin(x.^2);
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item h
y = tan(100*pi.^x).^3;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item i
y = sin(x)./x;
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item j
y = log10(sin(x))/2 + cot(x-1);
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item l
y = sum(sin(x)).*sum(cos(x).^3);
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])

% item m
y = real(log10(-x))./imag(log10(-x.^2));
disp(['y(2<x<19) = [ ' num2str(y) ' ]'])









