clc;
clear all;
% Calcule o valor de y para as opera��es abaixo.

py1 = [ 1 0 0 0 1 2 ];
y1 = polyder( py1 )

py2 = [ 1 0 1 0 0 1 0 ];
y2 = polyder( py2 )

py3 = [ 1 0 0 0 0 1 2 2 ];
y3 = polyint( py3 )

py4 = [ 1 0 0 1 0 0 0 2 0 ];
y4 = polyint( py4 )

