% Construa um vetor com elementos crescentes que come�a em 10 e termina em 20, com passo de 5.
v1 = 1:5:20

% Construa um vetor com elementos crescentes que come�a em 10 e termina em 20, com 7 elementos.
v2 = linspace( 10, 20, 7 )

% Gere uma seq��ncia de n�meros pares come�ando em 4 e terminando em 15
v3 = 4:2:15