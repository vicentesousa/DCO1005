clear all;
clc;
% Encontrar o valor de x1, x2 e x3:
A = [-1, 2, 0;0.5 9 3;2 4 5]
B = [3; -2; 7]
C = A\B
% C�lculo de outra forma
C2 = inv(A)*B

clear all;
% Sendo A = [1 2;3 4] e B = [10 20; 30 40], calcule
A = [1 2;3 4];
B = [10 20; 30 40];

A + B

A - B

A * B

A .* B




