% Seja x=[5 2] e y=[2 3 4].
x=[5 2]; y=[2 3 4];

% a) A express�o S=x+y ser� processada corretamente? Justifique.

% Resposta: N�o, pois as matrizes tem dimens�o diferentes. O Matlab avisa 
%           isso logo que se tenta processar x + y. Veja:
%
%??? Error using ==> plus
%Matrix dimensions must agree.

%Error in ==> vetor_exec5 at 5
%x + y

% b) Fa�a  uma express�o que divida x pelos 2 primeiros elementos de y.
d = x ./ y( 1:2 )