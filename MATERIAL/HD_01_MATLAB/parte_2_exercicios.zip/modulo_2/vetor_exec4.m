% Extraia os 4 �ltimos elementos do vetor a e armazene na vari�vel c: 
a = [1 30 100 3 10 30 90 1 2 3 4 50 90 0.9]

% Use operador end e tamb�m o comando length
c = a( end-3:end )

c = a( length(a)-3:length(a) )