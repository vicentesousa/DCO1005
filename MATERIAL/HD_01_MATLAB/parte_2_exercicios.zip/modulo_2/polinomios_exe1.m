% Polinomios
clear all;
clc;
%Exerc�cio: Calcular as ra�zes dos seguintes polin�mios.
p1 = [-7/3 0 -16/3 25 0];
r1 = roots(p1)
p2 = [1 -9 0 0 0 0 0 2];
r2 = roots(p2)

%Exerc�cio: Calcular os polin�mios a partir das seguintes ra�zes.
r3 = [3 2 0];
p3 = poly(r3)

r4 = [3 1+j 1-j];
p4 = poly(r4)