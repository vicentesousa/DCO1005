% Calcule o valor de y para as opera��es abaixo.
clc;
clear all;

% item a
ny1 = [ 1 3 6 4 1 1];
dy1 = [ 1 1 ];
[ y1 , r1 ]= deconv( ny1, dy1 )


% item b
ny2 = [ 1 2 4 0 1 ];
dy2 = [ 1 1 ];
y2 = conv( ny2, dy2 )

% item c
ny3 = [ 1 2 2 ];
dy3 = [ 1 0 0 0 0 0 0 1 ];
y3  = conv( ny3, dy3 )

% item d
ny4 = [ 1 2 1 ];
dy4 = [ 1 1 ];
[ y4 , r4 ]= deconv( ny4, dy4 )


