clc;
clear all;
% Calcule o vetor y para as opera��es abaixo:
p1 = [ 3 1 3 9 ];
p2 = [ 3 2 4 8 ];
y1 = p1 * p2'

% Multiplicar elemento a elemento dos vetores:
a = [ 0.5 2 3+2j 13 5 10];
b = [ 1 2 3 4 5 6];
ab = a .* b

% Dividir elemento a elemento dos vetores:
c = [ 0.5 2 3+2j 13 5 10];
d = [ 1 2 3 4 5 6];
cd = c ./ d