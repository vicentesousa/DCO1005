clc;
clear all;
% Crie um vetor A de 50 elementos aleat�rios e a partir deste crie outros 
% vetores obedecendo aos seguintes crit�rios:
A = rand(1,10)

% B1 = Conter somente os elementos de A maiores que 0.5
B1 = A( A > 0.5  )

% B2 = Conter os elementos de A em ordem crescente
B2 = sort( A )

% B3 = Conter os elementos de A em ordem decrescente
B3 = B2( end:-1:1 )
