function F = converter2(C)

F = 9*C/5 + 32;

disp([ 'Temperatura em Celsius: ' num2str(C) ' C-> ' num2str(F) ' Fahrenheit' ]);
