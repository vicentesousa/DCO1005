%geladeira
compras(1).nome = 'Geladeira';
compras(1).precounitario = 2500;
compras(1).quantidade = 1;
compras(1).precototal = compras(1).quantidade * compras(1).precounitario;

% TV
compras(2).nome = 'TV';
compras(2).precounitario = 2300;
compras(2).quantidade = 2;
compras(2).precototal = compras(2).precototal * compras(2).quantidade;

% Rack
compras(3).nome = 'Rack';
compras(3).precounitario = 1500;
compras(3).quantidade = 1;
compras(3).precototal = compras(3).precototal * compras(3).quantidade;


