clc;
clear all;
x = 1+4^2;
disp(['x = 1+4^2 = ' num2str(x )]);

x = (1-4/3)^3 - 1;
disp(['x = (1-4/3)^3 - 1 = ' num2str(x )]);

x = (1+j)^2;
disp(['x = (1+j)^2 = ' num2str(x)]);

x = log(3)/2 + exp(-4*j);
disp(['x = log(3)/2 + exp(-4*j) = ' num2str(x)]);

x = 3/sqrt(2) - abs(1+4*j)^2;
disp(['x = 3/sqrt(2) - abs(1+4*j)^2 = ' num2str(x)]);

x = atan(sqrt(3)/3);
disp(['x = atan(sqrt(3)/3) = ' num2str(x)]);

x = angle(3+4*j);
disp(['x = angle(3+4*j) = ' num2str(x)]);

x = sin(pi/3)^3+cos(pi^2/4);
disp(['x = sen(pi/3)^3+cos(pi^2/4) = ' num2str(x)]);

x = (3)^(1/4);
disp(['x = (3)^(1/4) = ' num2str(x)]);

x = log2(7);
disp(['x = log2(7) = ' num2str(x)]);




