clc;
clear all;
C =37;
F = 9*C/5 + 32;
converter2(10)
disp([ 'Temperatura em Celsius: ' num2str(C) ' C-> ' num2str(F) ' Fahrenheit' ]);
save('temp')
