A = [-1, 2, 0;0.5 9 3;2 4 5]

B = [3; -2; 7]

C = A\B

% C�lculo de outra forma
C2 = inv(A)*B


