function [ compras_saida ] = addcompras( compras_entrada, nome, quant, preco )
% Fun��o para adicionar itens a estrutra compras composta dos segiuntes
% campos:
%
%   compras(X).nome = 'Geladeira';
%   compras(X).precounitario = 2500;
%   compras(X).quantidade = 1;
%   compras(X).precototal = compras(1).quantidade * compras(1).precounitario;
%
% Como usar: [ compras ] = addcompras( compras, 'cadeira', 10, 200 );
%
% Autor: Vicente Sousa, 19 de novembro de 2010, Natal/RN
%


%% calcula o �ltimos elemento
ultimo_elemento = length( compras_entrada );

%% Atualiza as compras
compras_entrada( ultimo_elemento + 1 ).nome = nome;
compras_entrada( ultimo_elemento + 1 ).precounitario = preco;
compras_entrada( ultimo_elemento + 1 ).quantidade = quant;
compras_entrada( ultimo_elemento + 1 ).precototal = quant * preco;

%% atualiza a sa�da
compras_saida = compras_entrada;
