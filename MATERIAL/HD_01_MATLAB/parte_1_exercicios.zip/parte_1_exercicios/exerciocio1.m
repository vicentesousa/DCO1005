clc;
% a)
x = 1 + 4^2;
saida = [ 'a) x = 1 + 4^2 = ' num2str(x )  ] ;
disp(saida)
% b)
x = 1 + 4^2;
saida = [ 'a) x = 1 + 4^2 = ' num2str(x )  ] ;
disp(saida)