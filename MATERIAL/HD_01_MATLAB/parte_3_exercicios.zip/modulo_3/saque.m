function [ saldo, extrato ] = saque( saldo, extrato)
clc;
disp(['Seu saldo em ' datestr(now) ' � R$ ' num2str(saldo)]);

saq = input('Digite quanto deseja sacar (digite 0 para sair): ');

if ( saq ~= 0 )
    
    if ( saq <= saldo )
        saldo = saldo - saq;
        extrato = [ extrato; [ datestr(now) ' Dep�sito ' num2str(saq) ] ];
        extrato = [ extrato; [ datestr(now) ' Novo Saldo ' num2str(saldo) ] ];
    else
        disp('Saldo insuficiente na conta.')
    end
end
