function varargout = GUI_converter2(varargin)
% GUI_CONVERTER2 M-file for GUI_converter2.fig
%      GUI_CONVERTER2, by itself, creates a new GUI_CONVERTER2 or raises the existing
%      singleton*.
%
%      H = GUI_CONVERTER2 returns the handle to a new GUI_CONVERTER2 or the handle to
%      the existing singleton*.
%
%      GUI_CONVERTER2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_CONVERTER2.M with the given input arguments.
%
%      GUI_CONVERTER2('Property','Value',...) creates a new GUI_CONVERTER2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_converter2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_converter2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_converter2

% Last Modified by GUIDE v2.5 19-Dec-2010 11:33:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_converter2_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_converter2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_converter2 is made visible.
function GUI_converter2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_converter2 (see VARARGIN)

% Choose default command line output for GUI_converter2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_converter2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_converter2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

tempC = str2num(get(handles.entrada_celsius,'string'));
K = tempC + 273;
F = tempC*9/5 + 32;

set(handles.saida_kelvin,'string', num2str(K) )
set(handles.saida_far,'string', num2str(F) )


function saida_kelvin_Callback(hObject, eventdata, handles)
% hObject    handle to saida_kelvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of saida_kelvin as text
%        str2double(get(hObject,'String')) returns contents of saida_kelvin as a double


% --- Executes during object creation, after setting all properties.
function saida_kelvin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saida_kelvin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function entrada_celsius_Callback(hObject, eventdata, handles)
% hObject    handle to entrada_celsius (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of entrada_celsius as text
%        str2double(get(hObject,'String')) returns contents of entrada_celsius as a double


% --- Executes during object creation, after setting all properties.
function entrada_celsius_CreateFcn(hObject, eventdata, handles)
% hObject    handle to entrada_celsius (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function saida_far_Callback(hObject, eventdata, handles)
% hObject    handle to saida_far (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of saida_far as text
%        str2double(get(hObject,'String')) returns contents of saida_far as a double


% --- Executes during object creation, after setting all properties.
function saida_far_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saida_far (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
