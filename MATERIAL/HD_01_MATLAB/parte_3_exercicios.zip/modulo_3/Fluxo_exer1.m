function Fluxo_exer1(C)

F = 9*C/5 + 32;
K = C + 273.15;

clc;
disp('#########################')
disp('Conversor de temperatura:')
disp('#########################')
disp(' ')

disp('Qual a escala voc� deseja converter?')
a = input('�Digite 0� para Fahrenheit e �Digite 1� para Kelvin: ');

if ( a == 0 )
    disp([ 'Temperatura em Celsius: ' num2str(C) ' graus Celsisus  -> ' num2str(F) ' Fahrenheit' ]);
elseif  ( a == 1 )
    disp([ 'Temperatura em Celsius: ' num2str(C) ' graus Celsisus  -> ' num2str(K) ' Kelvin' ]);
else
    disp('Op��o Inv�lida ')
end

