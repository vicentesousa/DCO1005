close all; clc; clear all;
t1 = [-pi:0.3:pi];
y1 = sin(t1);
plot(t1,y1,'r-')
Hold on;
y2 = cos(t1);
plot(t1,y2, 'b-')
legend('seno', 'coseno')
xlabel('Tempo')

% 1. Use o comando get para ver as propriedades da figura criada 
get(gcf)

% 2. Use o comando set para mudar a cor da figura para vermelho (use o padr�o RGB: [1 0 0] � vermelho)
set(gcf, 'color', [1 0 0])

% 3. Use o comando get para ver as propriedades do axes criado
get(gca)

% 4. Use o comando get acessar o objeto line (ver propriedade �children� do axes) 
linhas = get(gca, 'children' )
get(linhas(1))
get(linhas(2))

% 5. Use o comando set para mudar a legenda coseno para casino
set(linhas(1), 'DisplayName', 'casino')

% 6. Use o comando get acessar o objeto xlabel do axis 
objeto_label = get(gca,'xlabel')

% 7. Use o comando set para mudar o t�tulo do eixo x de Tempo para �ngulo (?)
set(objeto_label, 'string', '�ngulo (\beta)' )