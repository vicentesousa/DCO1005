close all;
clear all;
clc;
% grafico 1
t = [0:1000];
y = exp(10*t);
subplot(4,1,1);
loglog(t,y);
% grafico 2
subplot(4,1,2);
n=[-10 : 10];
y=sin(n)./n;
stem(n,y);
% grafico 3
subplot(4,1,3);
teta = [0 : 0.01 : 2*pi];
rho=sin(2*teta).*cos(2*teta)
polar(teta,rho,'--r')
% grafico 4
subplot(4,1,4);
t1 = [-pi:0.01:pi];
y1 = sin(t1);
t2 = [-pi:0.01:pi];
y2 = cos(t2)/2;
plot(t1,y1,'r',t2,y2,'b');
