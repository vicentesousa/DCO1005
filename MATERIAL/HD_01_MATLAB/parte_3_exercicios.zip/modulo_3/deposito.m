function  [ saldo, extrato ] = deposito( saldo, extrato)
clc;
disp(['Seu saldo em ' datestr(now) ' � R$ ' num2str(saldo)]);

dep = input('Digite quanto deseja depositar (digite 0 para sair): ');

if ( dep ~= 0 )
    saldo = saldo + dep;
    extrato = [ extrato; [ datestr(now) ' Dep�sito ' num2str(dep) ] ]; 
    extrato = [ extrato; [ datestr(now) ' Novo Saldo ' num2str(saldo) ] ]; 
end

