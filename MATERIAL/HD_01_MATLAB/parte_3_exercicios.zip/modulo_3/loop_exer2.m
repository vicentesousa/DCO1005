%%%%%%%%%%%%%%%%
% Bola
%%%%%%%%%%%%%%%%

%  Uma bola de borracha � solta de uma altura D, ao chocar-se contra o ch�o,
%  esta retorna a uma altura D/2. Fa�a um programa que calcule a dist�ncia
%  da bola ao solo ap�s N choques e a dist�ncia percorrida. Os par�metros
%  D e N devem ser atribu�dos pelo usu�rio.

N = input('Digite o n�mero de choques no ch�o: ');
altura = input('Digite a altura inicial: ');
distancia = 0;
for ik = 1 : N
    
    % distancia percorrida
    distancia = distancia + altura + altura/2;
    
    % calculo da distancia at� o solo
    altura = altura - altura/2; 
end

disp([' A altura final  = ' num2str(altura)])
disp([' A dist�ncia percorrida = ' num2str(distancia)])

