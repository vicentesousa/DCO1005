clear all;
clc;
disp('############### C�lculo do �ndica de Massa Corp�rea ############### ')

peso = input('Digite seu peso em kg: ');
altura = input('Digite sua altura em metros: ');

IMC = peso./ (altura)^2;

disp(['Seu IMC � ' num2str(IMC)]);
disp('');

if ( IMC <= 18.5 )
    disp(' Voc� est� abaixo do peso ideal.');
elseif ( IMC <= 25 )
    disp(' Parab�ns, voc� est� em seu peso normal.');
elseif ( IMC <= 30 )
    disp(' Voc� est� acima do seu peso (sobrepeso).');
elseif ( IMC <= 35 )
    disp(' Obesidade grau I.');
elseif ( IMC <= 40 )
    disp(' Obesidade grau II.');
else
    disp(' Obesidade grau III.');
end


