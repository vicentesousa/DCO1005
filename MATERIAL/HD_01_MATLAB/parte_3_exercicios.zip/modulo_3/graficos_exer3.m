%Exerc�cios Gr�ficos
clear all;clc;close all;
figure;
x = 0:10:100;
y = x.^2 + 1;
bar(x,y);
hold on;
e = std(y)*ones(size(x));
errorbar(x,y,e)

figure;
x = 0:0.1:4*pi;
y = 0:0.1:4*pi;
[X,Y] = meshgrid(x, y);
Z = sin(X) + cos(Y);
surf(X,Y,Z)
