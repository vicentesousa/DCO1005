% Banco MATLAB
% opera��es:
%    1. Dep�sito
%    2. Retirada
%    3. Extrato
%    4. Sair do banco
%clear all;
clc;
disp('BANCO MATLAB - SEJA BEM VINDO:');
disp(' ');

if ( exist('banco2.mat') == 0 )
  disp('Conta n�o existente, crie sua conta');
  saldo = input('Digite seu saldo inicial? ');
  extrato = { [ datestr(now) ' Saldo inicial ' num2str(saldo) ] }; 
  save('banco2.mat','saldo','extrato');
else
    load banco2.mat;
    disp('Conta existente, seu extrato �:');
    disp(extrato)
end

contaativa = 1;
while ( contaativa == 1 )
    disp('Qual opera��o deseja fazer:');
    disp('digite 1 para ver extrato');
    disp('digite 2 para ver saldo');
    disp('digite 3 para deposito');
    disp('digite 4 para retirada');
    disp('digite 5 para sair do banco');
    operacao = input('Digita a op��o desejada:');
    
    if ( operacao == 1 )
        clc;
        disp(['Seu extrato em ' datestr(now) ]);
        disp(extrato);
        input('Digite enter para continuar...');
    elseif ( operacao == 2 )
        clc;
        disp(['Seu saldo em ' datestr(now) ]);
        disp(['Saldo = R$ ' num2str(saldo)]);
        input('Digite enter para continuar...');
    elseif ( operacao == 3 )
        clc;
        disp(['Dep�sito:']);
        [ saldo, extrato ] = deposito( saldo, extrato);
        save('banco2.mat','saldo','extrato');        
        input('Digite enter para continuar...');
    elseif ( operacao == 4 )
        clc;
        disp(['Saque:']);
        [ saldo, extrato ] = saque( saldo, extrato);
        save('banco2.mat','saldo','extrato');  
        input('Digite enter para continuar...');
    elseif ( operacao == 5 )
        clc;
        disp('Muito obrigado por usar nosso banco');
        contaativa = 0; 
    end
end


