%Contagem
clear all;
clc;
disp('Digite 1 para come�ar e 0 para sair.');
opcao = input('Entre a op��o: '); 
if (opcao == 1 )
    for ik = 0 : 20
        pause(1);
        clc;
        if ( ik <= 10 )
            disp('Contagem progressiva');
            disp(ik);
        else
            disp('Contagem regresiva');
            disp(20-ik);
        end
    end
else
    disp('N�o fiz nada');
end